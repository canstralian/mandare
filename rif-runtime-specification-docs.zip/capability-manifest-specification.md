# Capability Manifest Specification

Version: 1.0.0

## Purpose

Defines the machine-readable declaration of executable capabilities.

## Manifest Structure

<Code value='{
  "manifest_version": "1.0",
  "capabilities": []
}'/>

## Capability Object

<Code value='{
  "id": "network.fetch",
  "version": "1.2.0",
  "description": "Perform outbound HTTP requests",
  "risk_class": "R2",
  "requires_confirmation": false,
  "permissions": [],
  "limits": {},
  "dependencies": []
}'/>

## Permission Types

- network
- filesystem
- process
- model
- secret
- automation
- external_api

## Limit Schema

<Code value='{
  "max_requests": 100,
  "max_bytes": 10485760,
  "timeout_seconds": 30
}'/>

## Dependency Resolution

Capabilities may depend on other capabilities.

Example:

<Code value='{
  "id": "automation.github",
  "dependencies": ["network.fetch", "secret.read"]
}'/>

## Grant Model

A capability is executable only when:

<List gap={2}><List.Item>declared in manifest</List.Item><List.Item>enabled by runtime</List.Item><List.Item>approved by governance</List.Item><List.Item>within limits</List.Item></List>

## Integrity

The manifest should be content-addressed or signed.

## Validation

Validation must fail on:

- duplicate IDs
- unknown permission types
- invalid risk classes
- circular dependencies
