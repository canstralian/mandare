# Evidence Bundle Specification

Version: 1.0.0

## Purpose

Defines the portable evidence package for audit and replay.

## Bundle Layout

<Code value='bundle/
├── manifest.json
├── input.json
├── context.json
├── governance.json
├── actions.json
├── output.json
├── telemetry.json
└── artifacts/'/>

## Manifest

<Code value='{
  "bundle_version": "1.0",
  "execution_id": "exec_001",
  "created_at": "2026-08-09T00:00:00Z",
  "hashes": {}
}'/>

## Hash Requirements

All files must be individually hashed using SHA-256.

## Input Record

Original user input or trigger.

## Context Record

- memory references
- policy snapshot
- configuration snapshot
- capability snapshot

## Governance Record

- risk class
- decision
- constraints
- rationale

## Actions Record

Ordered list of tool calls and external operations.

## Output Record

Final returned result.

## Telemetry Record

- duration_ms
- token_usage
- cost
- retries
- errors

## Artifact Handling

Binary artifacts are stored under artifacts/.

## Bundle Integrity

The manifest hash map is authoritative.

## Retention Classes

- short_term
- operational
- audit
- archival
