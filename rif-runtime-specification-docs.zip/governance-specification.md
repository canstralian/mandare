# Governance Specification

Version: 1.0.0

## Scope

Defines the formal governance evaluation model used by RIF Runtime.

## Governance Inputs

- execution intent
- identity context
- capability requests
- evidence references
- runtime configuration
- policy set
- budget constraints

## Risk Classes

<Table columnSizing="equal" rowDivider={1}><Table.Row header><Table.Cell><Text weight="semibold" value="Class"/></Table.Cell><Table.Cell><Text weight="semibold" value="Description"/></Table.Cell></Table.Row><Table.Row><Table.Cell>R0</Table.Cell><Table.Cell>Informational</Table.Cell></Table.Row><Table.Row><Table.Cell>R1</Table.Cell><Table.Cell>Low impact</Table.Cell></Table.Row><Table.Row><Table.Cell>R2</Table.Cell><Table.Cell>Moderate impact</Table.Cell></Table.Row><Table.Row><Table.Cell>R3</Table.Cell><Table.Cell>High impact</Table.Cell></Table.Row><Table.Row><Table.Cell>R4</Table.Cell><Table.Cell>Critical / external impact</Table.Cell></Table.Row></Table>

## Evaluation Stages

### Stage 1: Identity Validation
Verify actor and session identity.

### Stage 2: Intent Classification
Determine intent category and risk class.

### Stage 3: Policy Resolution
Load applicable policies.

### Stage 4: Capability Evaluation
Check requested capabilities against grants.

### Stage 5: Budget Evaluation
Validate time, cost, and execution limits.

### Stage 6: Safety Evaluation
Apply safety and escalation rules.

### Stage 7: Decision
Return governance decision.

## Decision Schema

<Code value='{
  "decision": "approve|constrain|escalate|reject",
  "risk_class": "R2",
  "constraints": [],
  "rationale": "",
  "policy_refs": [],
  "expires_at": null
}'/>

## Constraint Types

- read_only
- no_network
- no_file_write
- require_confirmation
- budget_cap
- tool_subset

## Escalation Rules

R4 executions must require explicit operator approval.

## Audit Requirements

Every decision must record:

- decision_id
- execution_id
- policy_hash
- evaluator_version
- timestamp
