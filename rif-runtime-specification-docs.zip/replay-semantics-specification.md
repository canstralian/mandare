# Replay Semantics Specification

Version: 1.0.0

## Purpose

Defines what it means to replay an execution.

## Replay Classes

### Exact Replay
Bit-for-bit equivalence.

### Deterministic Replay
Same logical outputs.

### Bounded Replay
Semantically equivalent outputs.

### Forensic Replay
Historical reconstruction only.

## Replay Inputs

- evidence bundle
- runtime version
- policy version
- capability versions

## Equivalence Levels

<Table columnSizing="equal" rowDivider={1}><Table.Row header><Table.Cell><Text weight="semibold" value="Level"/></Table.Cell><Table.Cell><Text weight="semibold" value="Requirement"/></Table.Cell></Table.Row><Table.Row><Table.Cell>E0</Table.Cell><Table.Cell>Identical bytes</Table.Cell></Table.Row><Table.Row><Table.Cell>E1</Table.Cell><Table.Cell>Identical structure</Table.Cell></Table.Row><Table.Row><Table.Cell>E2</Table.Cell><Table.Cell>Identical decisions</Table.Cell></Table.Row><Table.Row><Table.Cell>E3</Table.Cell><Table.Cell>Equivalent meaning</Table.Cell></Table.Row></Table>

## Non-Determinism

Sources:

- stochastic models
- network responses
- time
- randomness
- external state

## Replay Policy

The replay engine must declare the highest achieved equivalence level.

## Divergence Reporting

<Code value='{
  "achieved": "E2",
  "expected": "E1",
  "divergences": []
}'/>

## Time Semantics

Replay preserves original timestamps but does not reuse wall-clock time for evaluation.

## Side Effects

Replay must never repeat external side effects unless explicitly enabled.
