# ADR-0002: Evidence as authoritative record

**Status:** Accepted

## Context

Multiple potential sources of truth existed: logs, telemetry, memory, and outputs.

## Decision

The evidence ledger is the authoritative record for execution reconstruction.

## Consequences

- Replay is evidence-driven
- Logs are operational only
- Memory is contextual only

## Rationale

A single authoritative record reduces ambiguity during audit and replay.
