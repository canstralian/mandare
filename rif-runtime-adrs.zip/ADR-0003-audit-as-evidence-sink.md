# ADR-0003: Audit as evidence sink

**Status:** Accepted

## Context

Traditional audit systems often duplicate execution data.

## Decision

Audit consumes evidence rather than creating a parallel audit trail.

## Consequences

- No dual-write inconsistency
- Simpler retention
- Unified verification

## Rationale

Evidence should be produced once and consumed many times.
