# ADR-0005: Replay as divergence verification

**Status:** Accepted

## Context

Replay could be interpreted as exact regeneration.

## Decision

Primary replay goal is divergence verification, not bitwise regeneration.

## Consequences

- Supports stochastic models
- Focuses on semantic equivalence
- Produces explicit divergence reports

## Rationale

Modern AI systems are often non-deterministic; verification is more valuable than strict reproduction.
