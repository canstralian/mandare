# ADR-0008: Documentation as generated artifact

**Status:** Accepted

## Context

Documentation can drift from runtime schemas and policies.

## Decision

Documentation is generated from authoritative runtime artifacts whenever possible.

## Consequences

- Reduced drift
- Easier updates
- Requires generation tooling

## Rationale

Executable artifacts should define the system; documentation should reflect them.
