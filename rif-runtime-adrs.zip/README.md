# Architecture Decision Records

This directory contains the initial Architecture Decision Records (ADRs) for RIF Runtime.

## Status

- Accepted
- Proposed
- Superseded
- Deprecated

## ADR Index

- ADR-0001 Governance as subsystem, not decorators
- ADR-0002 Evidence as authoritative record
- ADR-0003 Audit as evidence sink
- ADR-0004 Memory/context separation
- ADR-0005 Replay as divergence verification
- ADR-0006 Capability gateway as uniform control point
- ADR-0007 Adaptation applies only to future executions
- ADR-0008 Documentation as generated artifact
