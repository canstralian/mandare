# ADR-0006: Capability gateway as uniform control point

**Status:** Accepted

## Context

Different tools and providers had inconsistent authorization paths.

## Decision

All external actions pass through a single capability gateway.

## Consequences

- Consistent policy enforcement
- Uniform telemetry
- Easier revocation

## Rationale

Control points should be few, explicit, and observable.
