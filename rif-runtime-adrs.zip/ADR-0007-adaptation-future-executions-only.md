# ADR-0007: Adaptation applies only to future executions

**Status:** Accepted

## Context

Self-adaptation could affect historical replay.

## Decision

Adaptation may influence only executions started after the adaptation becomes effective.

## Consequences

- Historical stability
- Replay integrity
- Clear version boundaries

## Rationale

Past executions must remain interpretable under their original conditions.
