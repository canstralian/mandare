# ADR-0001: Governance as subsystem, not decorators

**Status:** Accepted

## Context

Governance concerns were initially considered as lightweight decorators around execution functions.

## Decision

Implement governance as a dedicated runtime subsystem with explicit inputs, outputs, state, and evidence emission.

## Consequences

### Positive

- Centralized policy enforcement
- Replayable decisions
- Uniform telemetry
- Easier auditing

### Negative

- Additional complexity
- More explicit data flow

## Rationale

Governance is a first-class architectural concern, not a cross-cutting convenience layer.
