# ADR-0004: Memory/context separation

**Status:** Accepted

## Context

Persistent memory and execution context were becoming coupled.

## Decision

Separate long-term memory from per-execution context assembly.

## Consequences

- Cleaner replay
- Better privacy boundaries
- Explicit context construction

## Rationale

Memory is a source; context is a constructed view.
